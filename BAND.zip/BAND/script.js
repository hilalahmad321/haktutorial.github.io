//     side navbar

function openbtn(){
    document.getElementById("mysidebar").style.width="100%";
}
function closebtn(){
   document.getElementById("mysidebar").style.width="0%";
}


//      img slider

var slideindex=0;
showSlides();
function showSlides(){
    var i;
    var slides=document.getElementsByClassName("myslides");
    for(i=0;i<slides.length;i++){
        slides[i].style.display= "none";
    }
    slideindex++;
    if(slideindex>slides.length){
        slideindex=1;
    }
    slides[slideindex-1].style.display= "block";
    setTimeout(showSlides,2000);
}


//            animation to website

AOS.init({
    duration:500,
});